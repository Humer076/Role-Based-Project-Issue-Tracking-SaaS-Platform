import { useEffect, useState } from "react";

function MyTasks() {
  const token = localStorage.getItem("token");
  const decoded = token ? JSON.parse(atob(token.split(".")[1])) : null;
  const userId = decoded?.id;

  const [tasks, setTasks] = useState([]);

  const fetchTasks = async () => {
    try {
      const res = await fetch(
        "http://localhost:5000/api/tasks",
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      const data = await res.json();

      // Backend already filters by assigned_to
      setTasks(data);

    } catch (error) {
      console.error("FETCH TASK ERROR:", error);
    }
  };

  useEffect(() => {
    fetchTasks();
  }, []);

  const updateStatus = async (taskId, newStatus) => {
    try {
      await fetch(
        `http://localhost:5000/api/tasks/${taskId}`,
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({ status: newStatus }),
        }
      );

      fetchTasks();

    } catch (error) {
      console.error("UPDATE STATUS ERROR:", error);
    }
  };

  return (
    <div style={{ padding: "40px" }}>
      <h2>My Tasks</h2>

      {tasks.length === 0 ? (
        <p>No tasks assigned</p>
      ) : (
        tasks.map((task) => (
          <div
            key={task.id}
            style={{
              border: "1px solid gray",
              margin: "10px 0",
              padding: "10px",
            }}
          >
            <h4>{task.title}</h4>
            <p>{task.description}</p>
            <p>Status: {task.status}</p>

            <button onClick={() => updateStatus(task.id, "pending")}>
              Pending
            </button>
            <button onClick={() => updateStatus(task.id, "in-progress")}>
              In Progress
            </button>
            <button onClick={() => updateStatus(task.id, "completed")}>
              Completed
            </button>
          </div>
        ))
      )}
    </div>
  );
}

export default MyTasks;