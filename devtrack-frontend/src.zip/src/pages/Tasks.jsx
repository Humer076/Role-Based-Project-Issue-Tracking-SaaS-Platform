import { useEffect, useState } from "react";
import axios from "axios";
import { useLocation } from "react-router-dom";

function Tasks() {
  const [tasks, setTasks] = useState([]);
  const token = localStorage.getItem("token");
  const location = useLocation();

  const status = new URLSearchParams(location.search).get("status");

  useEffect(() => {
    fetchTasks();
  }, [status]);

  const fetchTasks = async () => {
    try {
      const res = await axios.get(
        `http://localhost:5000/api/tasks${status ? `?status=${status}` : ""}`,
        {
          headers: { Authorization: `Bearer ${token}` }
        }
      );
      setTasks(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div>
      <h2>Tasks {status && `- ${status}`}</h2>
      {tasks.map((task) => (
        <div key={task.id}>
          <strong>{task.title}</strong> — {task.status}
        </div>
      ))}
    </div>
  );
}

export default Tasks;