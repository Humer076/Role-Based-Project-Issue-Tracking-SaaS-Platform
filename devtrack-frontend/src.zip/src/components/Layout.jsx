import { useNavigate } from "react-router-dom";

function Layout({ children }) {
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/");
  };

  return (
    <div style={{ padding: "30px", maxWidth: "1200px", margin: "auto" }}>
      <h1>DevTrack 🚀</h1>
      <button onClick={handleLogout}>Logout</button>
      <hr />
      {children}
    </div>
  );
}

export default Layout;